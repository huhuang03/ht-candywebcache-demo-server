function displayDate() {
document.getElementById("demo").innerHTML="1026-02";
}
