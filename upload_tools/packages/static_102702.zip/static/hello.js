function displayDate() {
document.getElementById("demo").innerHTML="1027-02";
}
